# VNF-on-Juniper-NFX-with-Ansible

Simple launch of VNF on NFX using Ansible playbooks:
- pb used to generate the config of the VNF if using config-drive (iso file)
- pb used to load the image of the VNF on NFX
- pb used to generate the VNF descriptor used on NFX
- pb used to launch the VNF on NFX
- pb used to stop the VNF on NFX
- pb used to cleanup files on NFX

Target VNF: vSRX, Ubuntu
